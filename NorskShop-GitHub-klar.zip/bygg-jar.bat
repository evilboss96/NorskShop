@echo off
setlocal
cd /d "%~dp0"
title Bygg NorskShop JAR
where java >nul 2>&1
if errorlevel 1 (
 echo FEIL: Java mangler. Installer JDK 21.
 goto :fail
)
where mvn >nul 2>&1
if errorlevel 1 (
 echo FEIL: Maven mangler.
 echo Installer Maven, og start terminalen paa nytt.
 echo Tips: winget install Apache.Maven
 goto :fail
)
call mvn -U clean package
if errorlevel 1 goto :fail
if not exist "target\NorskShop.jar" goto :fail
echo.
echo FERDIG: %cd%\target\NorskShop.jar
explorer "target"
pause
exit /b 0
:fail
echo.
echo JAR kunne ikke bygges. Se feilmeldingen over.
pause
exit /b 1
