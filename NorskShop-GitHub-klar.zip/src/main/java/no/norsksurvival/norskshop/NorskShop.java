package no.norsksurvival.norskshop;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.*;
import org.bukkit.block.*;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class NorskShop extends JavaPlugin implements Listener, CommandExecutor {
    private Economy economy;
    private File file;
    private final Map<String, Shop> shops = new HashMap<>();
    private final Map<UUID, Pending> pending = new ConcurrentHashMap<>();

    private static class Shop {
        String key, owner, material;
        int amount;
        double price;
        boolean buying;
        Shop(String key, String owner, String material, int amount, double price, boolean buying) {
            this.key=key; this.owner=owner; this.material=material; this.amount=amount; this.price=price; this.buying=buying;
        }
    }
    private record Pending(String key, String material, int amount) {}

    @Override public void onEnable() {
        saveDefaultConfig();
        RegisteredServiceProvider<Economy> reg = getServer().getServicesManager().getRegistration(Economy.class);
        if (reg == null || reg.getProvider() == null) {
            getLogger().severe("Ingen okonomileverandor funnet! Installer Vault + f.eks. EssentialsX Economy/CMI Economy.");
            getServer().getPluginManager().disablePlugin(this); return;
        }
        economy=reg.getProvider(); file=new File(getDataFolder(), "shops.yml"); load();
        getServer().getPluginManager().registerEvents(this,this);
        Objects.requireNonNull(getCommand("norskshop")).setExecutor(this);
        getLogger().info("NorskShop aktivert. " + shops.size() + " butikker lastet.");
    }
    @Override public void onDisable() { if(file!=null) save(); }
    private String key(Block b) { return b.getWorld().getUID()+":"+b.getX()+":"+b.getY()+":"+b.getZ(); }
    private Block block(String key) {
        try {
            String[] p=key.split(":"); World w=Bukkit.getWorld(UUID.fromString(p[0]));
            return w==null?null:w.getBlockAt(Integer.parseInt(p[1]),Integer.parseInt(p[2]),Integer.parseInt(p[3]));
        } catch (RuntimeException ex) {return null;}
    }
    private boolean chest(Block b) {return b.getState() instanceof Chest && ((Chest)b.getState()).getBlockInventory()!=null;}
    private boolean single(Block b) {return chest(b) && ((Chest)b.getState()).getInventory().getSize()==27;}
    private boolean owner(Player p, Shop s) {return p.getUniqueId().toString().equals(s.owner) || p.hasPermission("norskshop.admin");}
    private void msg(Player p,String s) {p.sendMessage(ChatColor.translateAlternateColorCodes('&',getConfig().getString("prefix", "&6NorskShop &8» &r")+s));}
    private boolean priceOK(double n){return Double.isFinite(n) && n>=getConfig().getDouble("minimum-price", .01) && n<=getConfig().getDouble("maximum-price",1000000);}
    private int count(Inventory inv, Material mat) {int total=0; for(ItemStack i:inv.getStorageContents()) if(i!=null && i.getType()==mat) total+=i.getAmount();return total;}
    private void remove(Inventory inv, Material mat, int count) {
        for(int k=0;k<inv.getSize() && count>0;k++) { ItemStack i=inv.getItem(k);if(i==null||i.getType()!=mat)continue;int n=Math.min(i.getAmount(),count);count-=n;if(n==i.getAmount())inv.setItem(k,null);else{i.setAmount(i.getAmount()-n);inv.setItem(k,i);} }
    }
    private int space(Inventory inv, Material mat) {
        int n=0; for(ItemStack i:inv.getStorageContents()) {if(i==null||i.getType()==Material.AIR)n+=mat.getMaxStackSize();else if(i.getType()==mat)n+=Math.max(0, i.getMaxStackSize()-i.getAmount());}return n;
    }
    private Inventory inv(Block b) {return ((Chest)b.getState()).getBlockInventory();}
    private Shop targeted(Player p) {
        Block b=p.getTargetBlockExact(5);return b==null?null:shops.get(key(b));
    }
    private void load() {
        shops.clear(); if(!file.exists())return;YamlConfiguration y=YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec=y.getConfigurationSection("shops");if(sec==null)return;
        for(String id:sec.getKeys(false)) {
            String path="shops."+id+".";
            String k=y.getString(path+"location", ""),o=y.getString(path+"owner", ""),m=y.getString(path+"material", "");
            if(!k.isBlank() && Material.matchMaterial(m)!=null)shops.put(k,new Shop(k,o,m,y.getInt(path+"amount",1),y.getDouble(path+"price",1),y.getBoolean(path+"buying",false)));
        }
    }
    private void save() {
        if(file==null)return;
        YamlConfiguration y=new YamlConfiguration();int index=0;
        for(Shop s:shops.values()) {String path="shops."+(index++)+".";y.set(path+"location",s.key);y.set(path+"owner",s.owner);y.set(path+"material",s.material);y.set(path+"amount",s.amount);y.set(path+"price",s.price);y.set(path+"buying",s.buying);}
        try {y.save(file);}catch(IOException ex){getLogger().severe("Kunne ikke lagre shops.yml: "+ex.getMessage());}
    }
    private void create(Player p, Pending pen, double price) {
        Block b=block(pen.key());
        if(b==null||!single(b)||shops.containsKey(pen.key())){msg(p,"&cKisten er borte, er dobbel, eller har allerede en butikk.");return;}
        long own=shops.values().stream().filter(s->s.owner.equals(p.getUniqueId().toString())).count();
        if(own>=getConfig().getInt("maximum-shops-per-player",20)&&!p.hasPermission("norskshop.admin")){msg(p,"&cDu har naadd maks antall butikker.");return;}
        Shop s=new Shop(pen.key(),p.getUniqueId().toString(),pen.material(),pen.amount(),price,false);
        shops.put(s.key,s);save();msg(p,"&aButikken er opprettet! &7"+s.amount+"x "+s.material+" for &e"+economy.format(price)+"&7. Legg varer i kisten.");
    }
    @EventHandler(priority=EventPriority.HIGH, ignoreCancelled=true) public void click(PlayerInteractEvent e) {
        if(e.getHand()!=EquipmentSlot.HAND || e.getClickedBlock()==null)return;
        Block b=e.getClickedBlock();String k=key(b);Shop s=shops.get(k);Player p=e.getPlayer();
        if(s==null && e.getAction()==Action.LEFT_CLICK_BLOCK && single(b) && p.hasPermission("norskshop.create") && p.hasPermission("norskshop.use")) {
            ItemStack hand=p.getInventory().getItemInMainHand();
            if(hand.getType().isAir())return;
            if(hand.hasItemMeta()){msg(p,"&cSpesialgjenstander støttes ikke i denne versjonen.");return;}
            e.setCancelled(true);pending.put(p.getUniqueId(),new Pending(k,hand.getType().name(),hand.getAmount()));
            msg(p,"&eSkriv pris i chatten for &f"+hand.getAmount()+"x "+hand.getType().name()+"&e, eller &cavbryt&e.");return;
        }
        if(s==null)return;
        if(e.getAction()==Action.LEFT_CLICK_BLOCK){e.setCancelled(true);show(p,s);return;}
        if(e.getAction()!=Action.RIGHT_CLICK_BLOCK)return;
        if(p.isSneaking() && owner(p,s))return;
        e.setCancelled(true);
        if(!p.hasPermission("norskshop.use")){msg(p,"&cDu har ikke tilgang.");return;}
        if(owner(p,s)){show(p,s);return;}
        trade(p,s,b);
    }
    private void show(Player p,Shop s){msg(p,"&e"+(s.buying?"KJOPER":"SELGER")+" &f"+s.amount+"x "+s.material+" &7for &a"+economy.format(s.price)+"&7. " +(s.buying?"Hoyreklikk for a selge.":"Hoyreklikk for a kjope."));}
    private void trade(Player p, Shop s, Block b) {
        if(!single(b)){msg(p,"&cButikken er ikke tilgjengelig.");return;}
        Material mat=Material.matchMaterial(s.material);if(mat==null||s.amount<1||!priceOK(s.price))return;
        Inventory stock=inv(b);Inventory bag=p.getInventory();OfflinePlayer seller=Bukkit.getOfflinePlayer(UUID.fromString(s.owner));
        if(!s.buying) {
            if(count(stock,mat)<s.amount){msg(p,"&cButikken er tom.");return;}
            if(space(bag,mat)<s.amount){msg(p,"&cDu har ikke nok plass i sekken.");return;}
            if(!economy.has(p,s.price)){msg(p,"&cDu har ikke nok penger.");return;}
            if(!economy.withdrawPlayer(p,s.price).transactionSuccess()){msg(p,"&cBetalingen mislyktes.");return;}
            if(!economy.depositPlayer(seller,s.price).transactionSuccess()) {economy.depositPlayer(p,s.price);msg(p,"&cKunne ikke betale butikkeieren.");return;}
            remove(stock,mat,s.amount);bag.addItem(new ItemStack(mat,s.amount));msg(p,"&aKjøpt &f"+s.amount+"x "+mat+" &afor "+economy.format(s.price));
        } else {
            if(count(bag,mat)<s.amount){msg(p,"&cDu har ikke nok varer.");return;}
            if(space(stock,mat)<s.amount){msg(p,"&cButikkkisten er full.");return;}
            if(!economy.has(seller,s.price)){msg(p,"&cButikkeieren har ikke nok penger.");return;}
            if(!economy.withdrawPlayer(seller,s.price).transactionSuccess()){msg(p,"&cBetalingen mislyktes.");return;}
            if(!economy.depositPlayer(p,s.price).transactionSuccess()) {economy.depositPlayer(seller,s.price);msg(p,"&cKunne ikke betale deg.");return;}
            remove(bag,mat,s.amount);stock.addItem(new ItemStack(mat,s.amount));msg(p,"&aSolgt &f"+s.amount+"x "+mat+" &afor "+economy.format(s.price));
        }
    }
    @EventHandler public void chat(AsyncPlayerChatEvent e) {
        Pending pen=pending.remove(e.getPlayer().getUniqueId());if(pen==null)return;e.setCancelled(true);
        String value=e.getMessage().trim().replace(',','.');
        Bukkit.getScheduler().runTask(this,()->{
            if(value.equalsIgnoreCase("avbryt")){msg(e.getPlayer(),"&7Opprettelse avbrutt.");return;}
            try {double price=Double.parseDouble(value);if(!priceOK(price)){msg(e.getPlayer(),"&cUgyldig pris. Prøv på nytt med kisten.");return;}create(e.getPlayer(),pen,price);}
            catch(NumberFormatException ex){msg(e.getPlayer(),"&cUgyldig pris. Venstreklikk kisten for å prøve igjen.");}
        });
    }
    @EventHandler(ignoreCancelled=true) public void breakBlock(BlockBreakEvent e){Shop s=shops.get(key(e.getBlock()));if(s==null)return;if(!owner(e.getPlayer(),s)){e.setCancelled(true);msg(e.getPlayer(),"&cDette er en beskyttet butikk.");}else{shops.remove(s.key);save();msg(e.getPlayer(),"&eButikken er fjernet.");}}
    @EventHandler(ignoreCancelled=true) public void place(BlockPlaceEvent e){if(e.getBlockPlaced().getType()!=Material.CHEST)return;for(BlockFace side:new BlockFace[]{BlockFace.NORTH,BlockFace.EAST,BlockFace.SOUTH,BlockFace.WEST})if(shops.containsKey(key(e.getBlockPlaced().getRelative(side)))){e.setCancelled(true);msg(e.getPlayer(),"&cKan ikke lage dobbelkiste ved en butikk.");return;}}
    @EventHandler(ignoreCancelled=true) public void explode(BlockExplodeEvent e){e.blockList().removeIf(b->shops.containsKey(key(b)));}
    @EventHandler(ignoreCancelled=true) public void explodeEntity(org.bukkit.event.entity.EntityExplodeEvent e){e.blockList().removeIf(b->shops.containsKey(key(b)));}
    @EventHandler(ignoreCancelled=true) public void move(InventoryMoveItemEvent e){if(e.getSource().getHolder() instanceof Chest source && shops.containsKey(key(source.getBlock()))) e.setCancelled(true);
        if(e.getDestination().getHolder() instanceof Chest dest && shops.containsKey(key(dest.getBlock()))) e.setCancelled(true);}
    @EventHandler(ignoreCancelled=true) public void inventoryOpen(org.bukkit.event.inventory.InventoryOpenEvent e){if(!getConfig().getBoolean("protect-chests",true)||!(e.getPlayer() instanceof Player p))return;if(e.getInventory().getHolder() instanceof Chest c){Shop s=shops.get(key(c.getBlock()));if(s!=null&&!owner(p,s)){e.setCancelled(true);msg(p,"&cDenne kisten tilhorer en butikk.");}}}
    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args) {
        if(!(sender instanceof Player p)){sender.sendMessage("Kun i spillet.");return true;}
        if(args.length==0||args[0].equalsIgnoreCase("hjelp")){msg(p,"&e/nshop pris <belop> &7| &e/nshop antall <1-64> &7| &e/nshop kjop &7| &e/nshop salg &7| &e/nshop fjern &7| &e/nshop info");return true;}
        Shop s=targeted(p);if(s==null){msg(p,"&cSe pa en butikkkiste innen 5 blokker.");return true;}
        if(args[0].equalsIgnoreCase("info")){show(p,s);return true;}
        if(!owner(p,s)){msg(p,"&cDu eier ikke denne butikken.");return true;}
        switch(args[0].toLowerCase(Locale.ROOT)) {
            case "pris":
                if(args.length<2){msg(p,"&cBruk: /nshop pris <belop>");break;}
                try{double n=Double.parseDouble(args[1].replace(',','.'));if(!priceOK(n)){msg(p,"&cUgyldig pris.");break;}s.price=n;save();msg(p,"&aPris endret til "+economy.format(n));}catch(NumberFormatException ex){msg(p,"&cUgyldig tall.");}break;
            case "antall":
                if(args.length<2){msg(p,"&cBruk: /nshop antall <1-64>");break;}
                try{int n=Integer.parseInt(args[1]);if(n<1||n>64||n>Material.valueOf(s.material).getMaxStackSize()){msg(p,"&cUgyldig antall.");break;}s.amount=n;save();msg(p,"&aAntall endret til "+n);}catch(NumberFormatException ex){msg(p,"&cUgyldig tall.");}break;
            case "kjop": s.buying=true;save();msg(p,"&aButikken kjoper na varer fra spillere.");break;
            case "salg": s.buying=false;save();msg(p,"&aButikken selger na varer til spillere.");break;
            case "fjern": shops.remove(s.key);save();msg(p,"&aButikken er fjernet. Kisten star igjen.");break;
            default:msg(p,"&cUkjent kommando. /nshop hjelp");
        }
        return true;
    }
}
