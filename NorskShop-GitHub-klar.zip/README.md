# NorskShop 1.0 — Norsk Survival

Egen norsk kistebutikk-plugin inspirert av QuickShop (ikke en kopi av den originale koden).

## Krav
- Spigot/Paper med Minecraft 1.21.x (API mål: 1.21.4), Java 21
- Vault og en Vault-kompatibel økonomileverandør, f.eks. CMI Economy eller EssentialsX Economy.
- Maven (for å kompilere kildekoden)

## Bygging
Åpne en terminal i mappen NorskShop og kjør `mvn clean package`. Da genereres `target/NorskShop.jar`. Kopier JAR til serverens `plugins`-mappe og restart serveren.

## Bruk
1. Sett ut en **enkel** kiste (dobbelkister støttes ikke i v1).
2. Hold en vanlig vare i hånden og venstreklikk på kisten.
3. Skriv pris i chat, f.eks. `150`. Skriv `avbryt` for å stoppe.
4. Legg varebeholdningen i kisten (Shift+høyreklikk for eieren).
5. Andre spillere høyreklikker på kisten for å kjøpe en pakke.
6. Se på kisten og kjør `/nshop kjop` hvis du vil kjøpe varer fra spillere (de betales fra din saldo).

## Kommandoer
`/nshop hjelp`, `/nshop info`, `/nshop pris 250`, `/nshop antall 8`, `/nshop kjop`, `/nshop salg`, `/nshop fjern`.
Alias: `/ns`, `/nshop`.

## LuckPerms
`/lp group default permission set norskshop.use true`
`/lp group default permission set norskshop.create true`
`/lp group admin permission set norskshop.admin true`

## Begrensninger i v1
- Ingen skilt, flytende vare, GUI, multi-currency, database eller integrasjon med WorldGuard/GriefPrevention.
- Bare vanlige varer uten metadata; ingen enchantments, custom items eller shulker-data.
- Bare enkelkister, maksimalt ett stack per transaksjon. Shop-opplysninger lagres i `plugins/NorskShop/shops.yml`.
- Overføringer via Vault er to separate operasjoner. Hvis en økonomileverandør feiler mellom operasjonene, bør saldoer kontrolleres i loggen; det finnes ingen atomisk transaksjonsgaranti.
- Før produksjonsbruk bør pluginen bygges, testkjøres, sikkerhetsgjennomgås og prøves med serverens øvrige beskyttelsesplugins.
- **Avinstaller eksisterende QuickShop/ChestShop** før du bruker NorskShop for å unngå dobbeltregistrerte butikkhandlinger.
